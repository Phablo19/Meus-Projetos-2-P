from pydantic import BaseModel

class Filme(BaseModel):
    nome: str
    genero: str
    ano: int
    diretor: str
