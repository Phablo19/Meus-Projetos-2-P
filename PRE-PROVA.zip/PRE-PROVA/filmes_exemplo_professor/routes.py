from fastapi import APIRouter
from schemas import Filme
from database import collection

router = APIRouter()

@router.post("/filmes")
def criar_filme(filme: Filme):
    collection.insert_one(filme.dict())
    return {"msg": "Filme cadastrado"}

@router.get("/filmes")
def listar_filmes():
    return list(collection.find({}, {"_id": 0}))

@router.put("/filmes/{nome}")
def atualizar_filme(nome: str, filme: Filme):
    collection.update_one({"nome": nome}, {"$set": filme.dict()})
    return {"msg": "Filme atualizado"}

@router.delete("/filmes/{nome}")
def deletar_filme(nome: str):
    collection.delete_one({"nome": nome})
    return {"msg": "Filme removido"}
