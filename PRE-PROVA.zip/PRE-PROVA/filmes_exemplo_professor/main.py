from fastapi import FastAPI
from routes import router

app = FastAPI(title="CRUD Filmes")

app.include_router(router)

@app.get("/")
def home():
    return {"mensagem": "API de Filmes funcionando"}
