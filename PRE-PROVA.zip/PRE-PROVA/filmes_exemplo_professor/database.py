from pymongo import MongoClient

client = MongoClient("mongodb://mongo:27017/")
db = client["crud_filmes"]
collection = db["filmes"]
