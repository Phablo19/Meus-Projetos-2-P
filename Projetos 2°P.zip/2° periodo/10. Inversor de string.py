string = input('Digite uma palavra: ')
inversao = string[-1]
print(inversao)