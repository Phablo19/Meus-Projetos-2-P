n = 0
while True:
    if n >= 100:
        break
    n = n + 1
    if n % 2 == 1:
        print(n,'impar')