vogais = ['a', 'e', 'o', 'u'[-1]]
palavras = input('digite uma palavra: ')
print(len(palavras))