x=0
y=1
print(y)
for i in range(0,9):
    print(x + y)
    temp = x
    x = y
    y = temp + y