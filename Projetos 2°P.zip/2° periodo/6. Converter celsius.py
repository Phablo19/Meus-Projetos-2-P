def conversao(a,b,c):
    return a * b + c
resultado = conversao(18, 1.8, 32)
print(resultado)