numeros = [1 ,5 ,7 ,2 ,13 ,9 ,3]

soma = numeros
print(sum(soma))