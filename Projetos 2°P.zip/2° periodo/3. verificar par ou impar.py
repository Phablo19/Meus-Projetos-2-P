total = int(input('Digite um valor: '))

if total % 2 == 0:
    print('par')
else:
    print('impar')