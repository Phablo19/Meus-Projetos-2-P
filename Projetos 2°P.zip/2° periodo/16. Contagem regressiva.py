import time

tempo = 10

for i in range(tempo, 0, -1):
    print(i)
    time.sleep(1)  

print("Acabou o tempo!!!")