n1 = float(input('Digite um número: '))
n2 = float(input('Digite um número: '))

total = n1 + n2
print(total)