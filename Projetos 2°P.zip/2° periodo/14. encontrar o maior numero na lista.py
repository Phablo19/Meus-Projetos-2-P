numeros = [1 ,5 ,7 ,2 ,13 ,9 ,3]

maior_num = numeros
print(max(maior_num))