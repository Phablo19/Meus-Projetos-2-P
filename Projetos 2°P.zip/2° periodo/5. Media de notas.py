n1 = float(input("Digite a nota da P1: "))
n2 = float(input("Digite a nota da P2: "))
n3 = float(input("Digite a nota da P3: "))

media = n1 + n2 + n3 / 2

print (media)