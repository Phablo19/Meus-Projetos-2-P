import math

resultado = math.factorial(9)
print(resultado)